﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class AdminService : IAdminService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public AdminService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<List<ProductDTO>>> GetLowStockProductsAsync()
    {
        var products = await _context.Products
            .Where(p => p.StockQuantity < 5)
            .ToListAsync();

        var dto = _mapper.Map<List<ProductDTO>>(products);
        return new ServiceResponse<List<ProductDTO>> { Data = dto };
    }

    public async Task<ServiceResponse<bool>> CreateDiscountAsync(DiscountDTO dto)
    {
        var product = await _context.Products.FindAsync(dto.ProductId);
        if (product == null)
            return new ServiceResponse<bool> { Success = false, Message = "Product not found" };

        product.DiscountPercentage = dto.Percentage;
        product.DiscountExpiresAt = dto.ExpiresAt;

        await _context.SaveChangesAsync();
        return new ServiceResponse<bool> { Data = true, Message = "Discount applied" };
    }

    public async Task<ServiceResponse<AnalyticsDTO>> GetSalesAnalyticsAsync()
    {
        var totalOrders = await _context.Orders.CountAsync();
        var totalRevenue = await _context.Orders.SumAsync(o => o.TotalAmount);
        var topProducts = await _context.OrderItems
            .GroupBy(i => i.ProductId)
            .OrderByDescending(g => g.Sum(i => i.Quantity))
            .Take(5)
            .Select(g => new TopProductDTO
            {
                ProductId = g.Key,
                QuantitySold = g.Sum(i => i.Quantity)
            }).ToListAsync();

        var analytics = new AnalyticsDTO
        {
            TotalOrders = totalOrders,
            TotalRevenue = totalRevenue,
            TopProducts = topProducts
        };

        return new ServiceResponse<AnalyticsDTO> { Data = analytics };
    }

    public async Task<ServiceResponse<List<OrderDTO>>> GetAllOrdersAsync()
    {
        var orders = await _context.Orders
            .Include(o => o.Items)
            .ThenInclude(i => i.Product)
            .ToListAsync();

        var dto = _mapper.Map<List<OrderDTO>>(orders);
        return new ServiceResponse<List<OrderDTO>> { Data = dto };
    }

    public async Task<ServiceResponse<List<UserDTO>>> GetAllUsersAsync()
    {
        var users = await _context.Users.ToListAsync();
        var dto = _mapper.Map<List<UserDTO>>(users);
        return new ServiceResponse<List<UserDTO>> { Data = dto };
    }
}