﻿using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BCrypt.Net;
using ECommerce.API.Helpers;
using System;

namespace ECommerce.API.Services.Implementation
{
    public class AuthService : IAuthService
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _configuration;

        public AuthService(AppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task<ServiceResponse<UserDTO>> RegisterAsync(RegisterDTO registerDto)
        {
            var response = new ServiceResponse<UserDTO>();
            if (await _context.Users.AnyAsync(u => u.Email == registerDto.Email))
            {
                response.Success = false;
                response.Message = "ელ.ფოსტა უკვე გამოყენებულია.";
                return response;
            }

            var passwordHash = BCrypt.Net.BCrypt.HashPassword(registerDto.Password);

            var user = new User
            {
                Email = registerDto.Email,
                PasswordHash = passwordHash,
                UserRole = Enums.UserRoles.Customer,
                CreatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            response.Data = new UserDTO { Email = user.Email, Role = user.UserRole.ToString() };
            response.Message = "რეგისტრაცია წარმატებით დასრულდა.";
            return response;
        }

        public async Task<ServiceResponse<string>> LoginAsync(LoginDTO loginDto)
        {
            var response = new ServiceResponse<string>();
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == loginDto.Email);

            if (user == null || !BCrypt.Net.BCrypt.Verify(loginDto.Password, user.PasswordHash))
            {
                response.Success = false;
                response.Message = "მომხმარებლის სახელი ან პაროლი არასწორია.";
                return response;
            }

            var token = CreateJwtToken(user);
            response.Data = token;
            response.Message = "ავტორიზაცია წარმატებით დასრულდა.";
            return response;
        }

        private string CreateJwtToken(User user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Role, user.UserRole.ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration.GetSection("Jwt:Key").Value));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }

        Task<ServiceResponse<int>> IAuthService.RegisterAsync(RegisterDTO dto)
        {
            throw new NotImplementedException();
        }
    }
}