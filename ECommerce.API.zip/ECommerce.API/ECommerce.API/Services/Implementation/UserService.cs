﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class UserService : IUserService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public UserService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<UserDTO>> GetUserByIdAsync(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
            return new ServiceResponse<UserDTO> { Success = false, Message = "User not found" };

        var dto = _mapper.Map<UserDTO>(user);
        return new ServiceResponse<UserDTO> { Data = dto };
    }

    public async Task<ServiceResponse<UserDTO>> UpdateUserAsync(int id, UserDTO dto)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
            return new ServiceResponse<UserDTO> { Success = false, Message = "User not found" };

        user.Name = dto.Name;
        user.Email = dto.Email;
        // პაროლის განახლება სურვილისამებრ

        await _context.SaveChangesAsync();
        var updatedDto = _mapper.Map<UserDTO>(user);
        return new ServiceResponse<UserDTO> { Data = updatedDto, Message = "User updated" };
    }

    public async Task<ServiceResponse<List<OrderDTO>>> GetUserOrdersAsync(int userId)
    {
        var orders = await _context.Orders
            .Include(o => o.Items)
            .ThenInclude(i => i.Product)
            .Where(o => o.UserId == userId)
            .ToListAsync();

        var dto = _mapper.Map<List<OrderDTO>>(orders);
        return new ServiceResponse<List<OrderDTO>> { Data = dto };
    }
}