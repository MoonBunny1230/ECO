﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class ContentService : IContentService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public ContentService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<ServiceResponse<List<ContentDTO>>> GetAllAsync()
    {
        var contents = await _context.Contents.ToListAsync();
        var dto = _mapper.Map<List<ContentDTO>>(contents);
        return new ServiceResponse<List<ContentDTO>> { Data = dto };
    }

    public async Task<ServiceResponse<ContentDTO>> GetByIdAsync(int id)
    {
        var content = await _context.Contents.FindAsync(id);
        if (content == null)
            return new ServiceResponse<ContentDTO> { Success = false, Message = "Content not found" };

        var dto = _mapper.Map<ContentDTO>(content);
        return new ServiceResponse<ContentDTO> { Data = dto };
    }

    public async Task<ServiceResponse<ContentDTO>> CreateAsync(ContentDTO dto)
    {
        var content = _mapper.Map<Content>(dto);
        _context.Contents.Add(content);
        await _context.SaveChangesAsync();

        var result = _mapper.Map<ContentDTO>(content);
        return new ServiceResponse<ContentDTO> { Data = result, Message = "Content created" };
    }

    public async Task<ServiceResponse<ContentDTO>> UpdateAsync(int id, ContentDTO dto)
    {
        var content = await _context.Contents.FindAsync(id);
        if (content == null)
            return new ServiceResponse<ContentDTO> { Success = false, Message = "Content not found" };

        _mapper.Map(dto, content);
        await _context.SaveChangesAsync();

        var result = _mapper.Map<ContentDTO>(content);
        return new ServiceResponse<ContentDTO> { Data = result, Message = "Content updated" };
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        var content = await _context.Contents.FindAsync(id);
        if (content == null)
            return new ServiceResponse<bool> { Success = false, Message = "Content not found" };

        _context.Contents.Remove(content);
        await _context.SaveChangesAsync();

        return new ServiceResponse<bool> { Data = true, Message = "Content deleted" };
    }
}