﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Implementation;

public interface AnalyticsService
{
   
}
