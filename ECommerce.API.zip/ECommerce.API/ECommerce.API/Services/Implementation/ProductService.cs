﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ECommerce.API.Services.Implementation
{
    public class ProductService : IProductService
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public ProductService(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<ServiceResponse<List<ProductDTO>>> GetProductsAsync(ProductFilterDTO filter)
        {
            var query = _context.Products.AsQueryable();

            if (filter.CategoryId.HasValue)
            {
                query = query.Where(p => p.CategoryId == filter.CategoryId.Value);
            }

            if (filter.MinPrice.HasValue)
            {
                query = query.Where(p => p.Price >= filter.MinPrice.Value);
            }

            if (filter.MaxPrice.HasValue)
            {
                query = query.Where(p => p.Price <= filter.MaxPrice.Value);
            }

            if (!string.IsNullOrEmpty(filter.SearchQuery))
            {
                query = query.Where(p => p.Name.Contains(filter.SearchQuery) || p.Description.Contains(filter.SearchQuery));
            }

            var totalCount = await query.CountAsync();

            var products = await query
                .Skip((filter.PageNumber - 1) * filter.PageSize)
                .Take(filter.PageSize)
                .ToListAsync();

            var productDtos = _mapper.Map<List<ProductDTO>>(products);

            var response = new ServiceResponse<List<ProductDTO>>
            {
                Data = productDtos,
                Success = true,
                Message = "პროდუქტები წარმატებით მოძიებულია.",
                TotalCount = totalCount
            };

            return response;
        }

        // ... სხვა მეთოდები
        public async Task<ServiceResponse<ProductDTO>> AddProductAsync(ProductDTO productDto)
        {
            var product = _mapper.Map<Product>(productDto);
            _context.Products.Add(product);
            await _context.SaveChangesAsync();
            return new ServiceResponse<ProductDTO> { Data = _mapper.Map<ProductDTO>(product), Success = true, Message = "პროდუქტი წარმატებით დაემატა." };
        }

        public async Task<ServiceResponse<ProductDTO>> UpdateProductAsync(int id, ProductDTO productDto)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return new ServiceResponse<ProductDTO> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };
            }

            _mapper.Map(productDto, product);
            await _context.SaveChangesAsync();
            return new ServiceResponse<ProductDTO> { Data = _mapper.Map<ProductDTO>(product), Success = true, Message = "პროდუქტი წარმატებით განახლდა." };
        }

        public async Task<ServiceResponse<bool>> DeleteProductAsync(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return new ServiceResponse<bool> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return new ServiceResponse<bool> { Data = true, Success = true, Message = "პროდუქტი წარმატებით წაიშალა." };
        }

        public async Task<ServiceResponse<ProductDTO>> GetProductByIdAsync(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return new ServiceResponse<ProductDTO> { Success = false, Message = "პროდუქტი ვერ მოიძებნა." };
            }
            return new ServiceResponse<ProductDTO> { Data = _mapper.Map<ProductDTO>(product), Success = true };
        }
    }
}