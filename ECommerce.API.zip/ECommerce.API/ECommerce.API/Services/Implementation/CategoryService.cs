﻿using AutoMapper;
using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Models;
using ECommerce.API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services.Implementation;

public class CategoryService : ICategoryService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public CategoryService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<IEnumerable<CategoryDTO>> GetAllAsync()
    {
        var categories = await _context.Categories
            .Include(c => c.Children)
            .Include(c => c.Parent)
            .ToListAsync();

        return _mapper.Map<IEnumerable<CategoryDTO>>(categories);
    }

    public async Task<CategoryDTO?> GetByIdAsync(int id)
    {
        var category = await _context.Categories
            .Include(c => c.Children)
            .Include(c => c.Parent)
            .FirstOrDefaultAsync(c => c.Id == id);

        return category != null ? _mapper.Map<CategoryDTO>(category) : null;
    }

    public async Task<CategoryDTO> CreateAsync(CategoryDTO dto)
    {
        var category = _mapper.Map<Category>(dto);

        _context.Categories.Add(category);
        await _context.SaveChangesAsync();

        return _mapper.Map<CategoryDTO>(category);
    }

    public async Task<CategoryDTO?> UpdateAsync(int id, CategoryDTO dto)
    {
        var category = await _context.Categories.FindAsync(id);
        if (category == null) return null;

        _mapper.Map(dto, category);
        category.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return _mapper.Map<CategoryDTO>(category);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var category = await _context.Categories.FindAsync(id);
        if (category == null) return false;

        // Check if category has products
        var hasProducts = await _context.Products.AnyAsync(p => p.CategoryId == id);
        if (hasProducts) return false; // Cannot delete category with products

        _context.Categories.Remove(category);
        await _context.SaveChangesAsync();
        return true;
    }
}