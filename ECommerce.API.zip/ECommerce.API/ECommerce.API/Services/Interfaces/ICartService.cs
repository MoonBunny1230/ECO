﻿using ECommerce.API.DTOs;

namespace ECommerce.API.Services.Interfaces;

public interface ICartService
{
    Task<CartDTO?> GetCartAsync(int userId);
    Task<CartDTO> AddItemAsync(int userId, CartItemDTO dto);
    Task<CartDTO?> UpdateQuantityAsync(int userId, int itemId, int quantity);
    Task<bool> RemoveItemAsync(int userId, int itemId);
    Task<bool> ClearCartAsync(int userId);
}