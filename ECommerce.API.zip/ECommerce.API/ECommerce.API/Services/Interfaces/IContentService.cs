﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IContentService
{
    Task<ServiceResponse<List<ContentDTO>>> GetAllAsync();
    Task<ServiceResponse<ContentDTO>> GetByIdAsync(int id);
    Task<ServiceResponse<ContentDTO>> CreateAsync(ContentDTO dto);
    Task<ServiceResponse<ContentDTO>> UpdateAsync(int id, ContentDTO dto);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
}