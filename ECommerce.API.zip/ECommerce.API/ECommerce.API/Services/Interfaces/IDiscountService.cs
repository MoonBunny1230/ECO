﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IDiscountService
{
    Task<ServiceResponse<DiscountDTO>> CreateAsync(DiscountDTO dto);
    Task<ServiceResponse<List<DiscountDTO>>> GetActiveAsync(); // GetActiveDiscountsAsync-ის ნაცვლად
    Task<ServiceResponse<bool>> DeleteAsync(int id); // RemoveAsync-ის ნაცვლად
}