﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;
using ECommerce.API.Models.Enums;

namespace ECommerce.API.Services.Interfaces;

public interface IOrderService
{
    Task<ServiceResponse<OrderDTO>> PlaceOrderAsync(int userId, CreateOrderDTO dto);
    Task<ServiceResponse<OrderDTO>> GetOrderByIdAsync(int id); // მხოლოდ ეს
    Task<ServiceResponse<List<OrderDTO>>> GetOrdersByUserAsync(int userId);
    Task<ServiceResponse<OrderDTO>> UpdateStatusAsync(int orderId, OrderStatus status);
}