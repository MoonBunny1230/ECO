﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface ICommentService
{
    Task<ServiceResponse<CommentDTO>> AddCommentAsync(int userId, CommentDTO dto);
    Task<ServiceResponse<List<CommentDTO>>> GetCommentsByProductAsync(int productId);
    Task<ServiceResponse<bool>> DeleteCommentAsync(int commentId, int userId);
}