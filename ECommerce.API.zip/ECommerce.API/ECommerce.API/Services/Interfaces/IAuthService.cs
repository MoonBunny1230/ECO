﻿using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IAuthService
{
    Task<ServiceResponse<UserDTO>> RegisterAsync(RegisterDTO dto);
    Task<ServiceResponse<string>> LoginAsync(LoginDTO dto);
}