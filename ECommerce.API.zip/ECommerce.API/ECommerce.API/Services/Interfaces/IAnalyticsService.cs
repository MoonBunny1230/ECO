﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IAnalyticsService
{
    Task<ServiceResponse<List<TopProductDTO>>> GetTopSellingProductsAsync();
    Task<ServiceResponse<AnalyticsDTO>> GetSummaryAsync();
}
