﻿using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces
{
    public interface IProductService
    {
        Task<ServiceResponse<ProductDTO>> AddProductAsync(ProductDTO productDto);
        Task<ServiceResponse<ProductDTO>> GetProductByIdAsync(int id);
        Task<ServiceResponse<List<ProductDTO>>> GetProductsAsync(ProductFilterDTO filter);
        Task<ServiceResponse<ProductDTO>> UpdateProductAsync(int id, ProductDTO productDto);
        Task<ServiceResponse<bool>> DeleteProductAsync(int id);
    }
}