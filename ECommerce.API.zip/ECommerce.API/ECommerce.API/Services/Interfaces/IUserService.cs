﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IUserService
{
    Task<ServiceResponse<UserDTO>> GetUserByIdAsync(int id);
    Task<ServiceResponse<UserDTO>> UpdateUserAsync(int id, UserDTO dto);
    Task<ServiceResponse<List<OrderDTO>>> GetUserOrdersAsync(int userId);
    Task<ServiceResponse<List<UserDTO>>> GetAllUsersAsync();
    Task<ServiceResponse<bool>> DeleteUserAsync(int id);
}