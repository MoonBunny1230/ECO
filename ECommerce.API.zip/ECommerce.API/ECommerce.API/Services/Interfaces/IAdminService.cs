﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ECommerce.API.DTOs;
using ECommerce.API.Helpers;

namespace ECommerce.API.Services.Interfaces;

public interface IAdminService
{
    Task<ServiceResponse<List<ProductDTO>>> GetLowStockProductsAsync();
    Task<ServiceResponse<bool>> CreateDiscountAsync(DiscountDTO dto);
    Task<ServiceResponse<AnalyticsDTO>> GetSalesAnalyticsAsync();
    Task<ServiceResponse<List<OrderDTO>>> GetAllOrdersAsync();
    Task<ServiceResponse<List<UserDTO>>> GetAllUsersAsync();
}