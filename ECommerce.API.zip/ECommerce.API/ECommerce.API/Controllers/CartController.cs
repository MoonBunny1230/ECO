﻿using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // ყველა მეთოდი დაცულია ავტორიზაციით
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;
        private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

        public CartController(ICartService cartService)
        {
            _cartService = cartService;
        }

        [HttpGet]
        public async Task<IActionResult> GetCart()
        {
            var response = await _cartService.GetCartByUserIdAsync(UserId);
            if (response.Success)
            {
                return Ok(response);
            }
            return NotFound(response);
        }

        [HttpPost("items")]
        public async Task<IActionResult> AddItemToCart([FromBody] CartItemDTO cartItemDto)
        {
            var response = await _cartService.AddItemToCartAsync(UserId, cartItemDto);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpDelete("items/{id}")]
        public async Task<IActionResult> RemoveItemFromCart(int id)
        {
            var response = await _cartService.RemoveItemFromCartAsync(UserId, id);
            if (response.Success)
            {
                return Ok(response);
            }
            return NotFound(response);
        }

        [HttpPut("items/{id}")]
        public async Task<IActionResult> UpdateCartItemQuantity(int id, [FromBody] int quantity)
        {
            var response = await _cartService.UpdateItemQuantityAsync(UserId, id, quantity);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }
    }
}