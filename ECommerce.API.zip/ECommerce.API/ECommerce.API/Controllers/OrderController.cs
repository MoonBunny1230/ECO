﻿using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;
using ECommerce.API.Models.Enums;


namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // ყველა მეთოდი დაცულია ავტორიზაციით
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

        public OrdersController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpPost]
        public async Task<IActionResult> PlaceOrder()
        {
            var response = await _orderService.PlaceOrderAsync(UserId);
            if (response.Success)
            {
                return CreatedAtAction(nameof(GetOrderById), new { id = response.Data.Id }, response);
            }
            return BadRequest(response);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrderById(int id)
        {
            var response = await _orderService.GetUserOrderAsync(UserId, id);
            if (response.Success)
            {
                return Ok(response);
            }
            return NotFound(response);
        }

        [HttpGet]
        public async Task<IActionResult> GetUserOrders()
        {
            var response = await _orderService.GetUserOrdersAsync(UserId);
            if (response.Success)
            {
                return Ok(response);
            }
            return NotFound(response);
        }

        [HttpPut("{id}/status")]
        [Authorize(Roles = "Admin")] // მხოლოდ ადმინებისთვის
        public async Task<IActionResult> UpdateOrderStatus(int id, [FromBody] OrderStatus newStatus)
        {
            var response = await _orderService.UpdateOrderStatusAsync(id, newStatus);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }
    }
}