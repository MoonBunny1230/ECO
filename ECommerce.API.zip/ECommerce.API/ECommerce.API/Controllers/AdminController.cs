﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IProductService _productService;
        private readonly IOrderService _orderService;

        public AdminController(
            IUserService userService,
            IProductService productService,
            IOrderService orderService)
        {
            _userService = userService;
            _productService = productService;
            _orderService = orderService;
        }

        [HttpGet("users")]
        public async Task<ActionResult<ServiceResponse<List<UserDTO>>>> GetAllUsers()
        {
            var response = await _userService.GetAllUsersAsync();
            return Ok(response);
        }

        [HttpGet("orders")]
        public async Task<ActionResult<ServiceResponse<List<OrderDTO>>>> GetAllOrders()
        {
            var response = await _orderService.GetAllOrdersAsync();
            return Ok(response);
        }

        [HttpGet("products")]
        public async Task<ActionResult<ServiceResponse<List<ProductDTO>>>> GetAllProducts()
        {
            var response = await _productService.GetAllAsync();
            return Ok(response);
        }

        [HttpPut("products/{id}")]
        public async Task<ActionResult<ServiceResponse<ProductDTO>>> UpdateProduct(int id, [FromBody] UpdateProductDTO updateProductDTO)
        {
            var response = await _productService.UpdateAsync(id, updateProductDTO);
            if (!response.Success) return NotFound(response);
            return Ok(response);
        }

        [HttpDelete("users/{id}")]
        public async Task<ActionResult<ServiceResponse<bool>>> DeleteUser(int id)
        {
            var response = await _userService.DeleteUserAsync(id);
            return Ok(response);
        }
    }
}