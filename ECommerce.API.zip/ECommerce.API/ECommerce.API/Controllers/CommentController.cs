﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Services.Interfaces;
using ECommerce.API.Helpers;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "User")]
    public class CommentController : ControllerBase
    {
        private readonly ICommentService _commentService;

        public CommentController(ICommentService commentService)
        {
            _commentService = commentService;
        }

        [HttpGet("{productId}")]
        public async Task<ActionResult<ServiceResponse<List<CommentDTO>>>> GetComments(int productId)
        {
            var response = await _commentService.GetCommentsForProductAsync(productId);
            return Ok(response);
        }

        [HttpPost]
        public async Task<ActionResult<ServiceResponse<CommentDTO>>> Create([FromBody] CreateCommentDTO createCommentDTO)
        {
            var response = await _commentService.CreateCommentAsync(createCommentDTO);
            return Ok(response);
        }
    }
}