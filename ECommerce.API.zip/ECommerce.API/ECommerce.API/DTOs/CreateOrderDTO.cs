﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class CreateOrderDTO
{
    [Required] public string ShippingAddress { get; set; }
    [Required] public string PaymentMethod { get; set; }

}