﻿namespace ECommerce.API.DTOs;

public class OrderSummaryDTO
{
    public int OrderId { get; set; }
    public DateTime CreatedDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public decimal TotalAmount { get; set; }
}
