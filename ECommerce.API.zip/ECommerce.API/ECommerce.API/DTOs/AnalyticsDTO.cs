﻿using System.Collections.Generic;

namespace ECommerce.API.DTOs;

public class AnalyticsDTO
{
    public int TotalOrders { get; set; }
    public decimal TotalRevenue { get; set; }
    public List<TopProductDTO> TopProducts { get; set; }
}