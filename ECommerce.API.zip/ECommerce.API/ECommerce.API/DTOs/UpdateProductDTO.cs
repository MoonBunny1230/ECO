﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class UpdateProductDTO : CreateProductDTO

{
    public int? DiscountPercentage { get; set; }
    public DateTime? DiscountExpiresAt { get; set; }

}