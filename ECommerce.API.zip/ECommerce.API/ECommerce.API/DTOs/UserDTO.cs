﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.DTOs;

public class UserDTO
{
    public int Id { get; set; }
    [Required] public string Name { get; set; }
    [Required][EmailAddress] public string Email { get; set; }
    public string Role { get; set; }

}