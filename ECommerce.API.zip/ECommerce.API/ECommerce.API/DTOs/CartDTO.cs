﻿using System.Collections.Generic;

namespace ECommerce.API.DTOs;

public class CartDTO
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public List<CartItemDTO> Items { get; set; }
    public decimal TotalAmount => Items?.Sum(i => i.Quantity * i.Price) ?? 0;
}
