﻿namespace ECommerce.API.Models.Enums;

public enum UserRole
{
    Customer = 0,
    Manager = 1,
    Admin = 2
}