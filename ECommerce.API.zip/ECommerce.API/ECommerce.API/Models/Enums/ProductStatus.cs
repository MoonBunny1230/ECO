﻿namespace ECommerce.API.Models.Enums;

public enum ProductStatus
{
    Active = 0,
    Inactive = 1,
    OutOfStock = 2
}