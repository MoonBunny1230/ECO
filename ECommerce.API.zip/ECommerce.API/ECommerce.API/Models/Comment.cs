﻿using System.ComponentModel.DataAnnotations;

namespace ECommerce.API.Models;

public class Comment
{
    public int Id { get; set; }

    public int ProductId { get; set; }
    public int UserId { get; set; }

    public string UserName { get; set; } = string.Empty;

    [Required]
    public string Text { get; set; } = string.Empty;

    [Range(1, 5)]
    public int Rating { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation Properties
    public Product Product { get; set; } = null!;
    public User User { get; set; } = null!;
}